bl_info = {
    "name": "Mario Kart 8 Tools",
    "author": "InfinaMii",
    "version": (1, 0, 3),
    "blender": (3, 3, 0),
    "category": "Render",
    "location": "View3D > Sidebar > MK8",
    "description": "Tools to assist with creating/modifying Mario Kart 8 courses",
    "doc_url": "https://github.com/InfinaMii/MK8-Mod-Docs/wiki/Baking-lights-and-shadows",
}

from decimal import localcontext
import math
import os
import bpy
import mathutils
import atexit

#from bpy_extras.io_utils import ExportHelper

class ObjPanel(bpy.types.Panel):
    """Mario Kart 8 Object Tools panel"""
    bl_idname = "mk.obj_panel"
    bl_label = "Object Tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "MK8"

    def draw(self, context):
        col = self.layout.column(align=True)
               
        col.label(text="Mesh Utilities")
        col.operator(DeselectNonMesh.bl_idname)
        col.operator(HomogeniseUVs.bl_idname)
        col.operator(RemoveColorAttributes.bl_idname)
        col.operator(AttrubutesToTextures.bl_idname)
        
        col.label(text="")
        col.label(text="MK8 Sun Rotation")
        row = col.row(align=True)
        row.prop(context.scene,"sun_rot_x")
        row.prop(context.scene,"sun_rot_y")
        row.prop(context.scene,"sun_rot_z")
        
        vts_row = col.row(align=True)
        vts_row.operator(ValuesToSun.bl_idname)
        stv_row = col.row(align=True)
        stv_row.operator(SunToValues.bl_idname)
        
        active_obj = bpy.context.view_layer.objects.active
        if not (active_obj.type == 'LIGHT' and active_obj.data.type == 'SUN'):
            vts_row.enabled = False
            stv_row.enabled = False

class ValuesToSun(bpy.types.Operator):
    """Converts Mario Kart 8 directions to the currently selected sun's rotation"""
    bl_idname = "mk.val_to_sun"
    bl_label = "Direction > Sun"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):

        light = bpy.context.view_layer.objects.active
        light_position = light.location.copy() #because vector is instanced

        offset = mathutils.Vector((0, 0, 0))
        offset.x = context.scene.sun_rot_x
        offset.z = context.scene.sun_rot_y
        offset.y = context.scene.sun_rot_z * -1
        
        direction = offset * -1
        direction.normalize()

        light.matrix_world = direction.to_track_quat('Z', 'Y').to_matrix().to_4x4()
        light.location = light_position
        
        return {'FINISHED'}
   
 
class SunToValues(bpy.types.Operator):
    """Converts rotation from the currently selected sun into Mario Kart 8 directions"""
    bl_idname = "mk.sun_to_val"
    bl_label = "Sun > Direction"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        
        mesh = bpy.data.meshes.new('emptyMesh')
        
        light = bpy.context.view_layer.objects.active
        
        new_obj = bpy.data.objects.new("stv_origin", mesh)
        offset = mathutils.Vector((0, 0, -1))  # because lights point below
        new_obj.location = light.matrix_world @ offset
        
        new_location = new_obj.location - light.location;
        
        context.scene.sun_rot_x = new_location.x
        context.scene.sun_rot_y = new_location.z
        context.scene.sun_rot_z = new_location.y * -1
        
        bpy.data.objects.remove(new_obj)
    
        return {'FINISHED'}
    
class DeselectNonMesh(bpy.types.Operator):
    """Removes all non-mesh objects from the current selection"""
    bl_idname = "mk.deselect_non_mesh"
    bl_label = "Deselect Non-Mesh Objects"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):        # execute() is called when running the operator.

        if len(bpy.context.selected_objects) > 0:
            non_meshes = []
            for obj in context.selected_objects:
                if not obj.type == 'MESH':
                    obj.select = False
        
            if bpy.context.active_object.select == False:
                bpy.context.view_layer.objects.active = context.selected_objects[0]
                
        return {'FINISHED'}
    
class HomogeniseUVs(bpy.types.Operator):
    """Makes the UV map names match for all selected objects"""
    bl_idname = "mk.homogenise_uv"
    bl_label = "Homogenise UV Names"
    bl_options = {'REGISTER', 'UNDO'}
    
    uv00: bpy.props.StringProperty(name="UV Map 1", default="texture", description="The name of the first UV map")
    uv01: bpy.props.StringProperty(name="UV Map 2", default="bake", description="The name of the second UV map")

    def execute(self, context):
        for obj in context.selected_objects:
             if obj.type == 'MESH':
                for i in range(len(obj.data.uv_layers)):
                    if (i == 0):
                        obj.data.uv_layers[i].name = self.uv00
                    elif (i == 1):
                        obj.data.uv_layers[i].name = self.uv01
                    else:
                        obj.data.uv_layers[i].name = f"UV{i + 1}"
                
        return {'FINISHED'}

class RemoveColorAttributes(bpy.types.Operator):
    """Removes color attributes for all selected objects"""
    bl_idname = "mk.remove_colors"
    bl_label = "Remove Color Attributes"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        for obj in bpy.context.selected_editable_objects:
            if obj.data.color_attributes:
                attrs = obj.data.color_attributes
                for r in range(len(obj.data.color_attributes)-1, -1, -1):
                    attrs.remove(attrs[r])
                    
        return {'FINISHED'}
    
class AttrubutesToTextures(bpy.types.Operator):
    """Converts vertex colors to BCP-style textures.\nDO NOT USE THIS ON TEXTURED OBJECTS, IT WILL MESS UP THEIR UV MAPS!!"""
    bl_idname = "mk.attribute_textures"
    bl_label = "Color Attributes to Textures"
    bl_options = {'REGISTER'}

    def execute(self, context):
        colors = []
        print("hi")
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                vcolors = obj.data.vertex_colors[0].data
                for polygon in obj.data.polygons:
                    for vertex in polygon.loop_indices:
                        color = vcolors[vertex].color
                        color_tuple = tuple(round(c, 4) for c in color)
                        if color_tuple not in colors:
                            colors.append(color_tuple)
        
        blob_size = 4
        grid = math.ceil(math.sqrt(len(colors)))
        size = grid * blob_size
        image = bpy.data.images.new(name="bcpgrid", width=size, height=size, alpha=True)
        pixels = [0.0] * len(image.pixels)
    
        for colorid in range(len(colors)):
            offset = (math.floor(colorid / grid) * size) + colorid % grid
            offset *= blob_size
            for x in range(blob_size):
                for y in range(blob_size):
                    index = x + (y * size) + offset
                    for i in range(4):
                        pixels[(index * 4) + i] = colors[colorid][i]
        image.pixels = pixels[:]

        material = bpy.data.materials.new(obj.name + "_bcpgrid")
        material.use_nodes = True
        node = material.node_tree.nodes.new(type='ShaderNodeTexImage')
        node.label = "color_grid"
        node.image = image
        bsdf = bsdf = get_bsdf_node(material.node_tree.nodes)
        material.node_tree.links.new(node.outputs["Color"], bsdf.inputs[0])

        indices = []
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                obj.data.materials.clear()
                obj.data.materials.append(material)
                
                uvertices = obj.data.uv_layers[0].data
                vcolors = obj.data.vertex_colors[0].data
                for polygon in obj.data.polygons:
                    for vertex in polygon.loop_indices:
                        color = vcolors[vertex].color
                        color_tuple = tuple(round(c, 4) for c in color)
                        index = colors.index(color_tuple)

                        if index not in indices:
                            indices.append(index)
                            print(index)

                        xpos = index % grid
                        ypos = math.floor(index / grid)
                        xpos /= grid
                        ypos /= grid

                        xpos += 2/size
                        ypos += 2/size
                        uvertices[vertex].uv = (xpos, ypos)
                        
        return {'FINISHED'}
    
## Bake Panel Items

class BakePanel(bpy.types.Panel):
    """Mario Kart 8 Bake Tools panel"""
    bl_idname = "mk.bake_panel"
    bl_label = "Bake Tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "MK8"

    def draw(self, context):
        
        col = self.layout.column(align=True)
               
        col.label(text="Object Setup")
        col.operator(AddBakeUV.bl_idname)
        col.operator(AddBakeTexture.bl_idname)

        row = col.row(align=True)
        row.operator(SelectBake.bl_idname)
        row.operator(SelectTexture.bl_idname)
        
        col.label(text="")
        col.label(text="Render Settings")
        col.operator(SetValues.bl_idname)
        col.operator(SetValuesSunset.bl_idname)
        col.operator(SetValuesNight.bl_idname)
        
        col.label(text="")
        col.prop(context.scene,"skybox_object")

        col.label(text="")
        col.label(text="Bake Selected Objects")
        bake_row = col.row()
        bake = bake_row.operator("object.bake", icon='RENDER_STILL')
        bake.type = bpy.context.scene.cycles.bake_type
        if context.scene.render_enum == "mk.render_none" or len(bpy.context.selected_objects) == 0 or select_includes_nonmesh():
            bake_row.enabled = False
        col.prop(context.scene,"render_enum")
        
        col.label(text="")
        col.label(text="Export")
        col.prop(context.scene,"render_dir")
        exp_row = col.row()
        exp_row.operator(ExportBakes.bl_idname)
        if len(context.scene.render_dir) < 2:
            exp_row.enabled = False
        
def select_includes_nonmesh():
    for obj in bpy.context.selected_objects:
        if not obj.type == 'MESH':
            return True
    return False
        
def update_render_type(self, context):
    eval('bpy.ops.' + context.scene.render_enum + '()')
    #print('called and changed to,', context.scene.render_enum)


# Properties

class AddBakeUV(bpy.types.Operator):
    """Adds a second UV map to the selected objects"""
    bl_idname = "mk.add_bake_uv"
    bl_label = "Add Bake UV Map to Selected"
    bl_options = {'REGISTER', 'UNDO'}
    
    bake_uv: bpy.props.StringProperty(name="UV Name", default="bake", description="The name of the bake UV map")

    def execute(self, context):        # execute() is called when running the operator.

        for obj in context.selected_objects:
            if obj.type == 'MESH':
                if len(obj.data.uv_layers) == 1:
                    obj.data.uv_layers.new(name=self.bake_uv)
                select_uv_slot(obj, 1)
                
        return {'FINISHED'}
    
class AddBakeTexture(bpy.types.Operator):
    """Adds a bake texture node to the selected objects"""
    bl_idname = "mk.add_bake_tex"
    bl_label = "Add Bake Texture to Selected"
    bl_options = {'REGISTER', 'UNDO'}
    
    texture_size_x: bpy.props.IntProperty(name="Texture Width", default=2048, description="The bake texture's width in pixels")
    texture_size_y: bpy.props.IntProperty(name="Texture Height", default=2048, description="The bake texture's height in pixels")
    texture_name: bpy.props.StringProperty(name="Texture Name", default="bake_texture", description="The name of the texture")

    def execute(self, context):        # execute() is called when running the operator.

        for obj in context.selected_objects:
            if obj.type == 'MESH':
                for slot in obj.material_slots:
                    
                    node = get_bake_node(slot.material.node_tree.nodes)
                    if node:
                        slot.material.node_tree.nodes.active = node
                    else:
                        node = slot.material.node_tree.nodes.new(type='ShaderNodeTexImage')
                        node.label = "bake_texture"
                        
                    slot.material.node_tree.nodes.active = node
                    if not node.image or not node.image.name == self.texture_name:
                        if bpy.data.images.get(self.texture_name, None):
                            node.image = bpy.data.images[self.texture_name]
                        else:
                            node.image = bpy.data.images.new(name=self.texture_name, width=self.texture_size_x, height=self.texture_size_y, alpha=True)
                
        return {'FINISHED'}
    
    
class SelectBake(bpy.types.Operator):
    """Makes sure the bake map is selected on all objects"""
    bl_idname = "mk.select_bake"
    bl_label = "Select Bake"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        for obj in context.scene.objects:
            if obj.type == 'MESH':
                if len(obj.data.uv_layers) > 1:
                    select_uv_slot(obj, 1)
                    
                for slot in obj.material_slots:
                    node = get_bake_node(slot.material.node_tree.nodes)
                    if node:
                        node.select = True
                        slot.material.node_tree.nodes.active = node
                    
        return {'FINISHED'}
            
class SelectTexture(bpy.types.Operator):
    """Makes sure the texture map is selected on all objects"""
    bl_idname = "mk.select_tex"
    bl_label = "Select Texture"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        for obj in context.scene.objects:
            if obj.type == 'MESH':
                if len(obj.data.uv_layers) > 0:
                    select_uv_slot(obj, 0)
                    
                for slot in obj.material_slots:
                    node = get_bsdf_node(slot.material.node_tree.nodes)
                    
                    if node and node.inputs['Base Color'].is_linked:
                        node.inputs['Base Color'].links[0].from_node.select = True
                        slot.material.node_tree.nodes.active = node.inputs['Base Color'].links[0].from_node
                        
        return {'FINISHED'}

    
# Property functions
    
def get_bake_node(nodes):
    for node in nodes:
        if node.label == "bake_texture":
            return node

def get_bsdf_node(nodes):
    for node in nodes:
        if 'BSDF' in node.type:
            return node
            
# Presets
    
class SetValues(bpy.types.Operator):
    """Sets the best daytime render values for Mario Kart 8 courses"""
    bl_idname = "mk.set_values"
    bl_label = "Daytime Preset"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        set_render_values(context, 125, 2.4)
        
        return {'FINISHED'}
    
class SetValuesSunset(bpy.types.Operator):
    """Sets the best sunset render values for Mario Kart 8 courses"""
    bl_idname = "mk.set_values_sunset"
    bl_label = "Sunset Preset"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        set_render_values(context, 150, 2.0)
        
        return {'FINISHED'}

class SetValuesNight(bpy.types.Operator):
    """Sets the best nighttime render values for Mario Kart 8 courses"""
    bl_idname = "mk.set_values_night"
    bl_label = "Nighttime Preset"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        set_render_values(context, 175, 0.4)
        
        return {'FINISHED'}
    

# Preset functions

def set_render_values(context, ao_distance, sun_strength):
    cycles = bpy.context.scene.cycles
    cycles.preview_samples = 50
    cycles.samples = 250
    cycles.use_denoising = False
        
    cycles.use_fast_gi = True
    bpy.data.worlds["World"].light_settings.distance = ao_distance
        
    bpy.context.scene.render.bake.margin = 3
        
    for light in bpy.data.lights:
        if light.type == 'SUN':
            light.energy = sun_strength
            light.angle = 0.174533
    

# Rendering

class RenderNone(bpy.types.Operator):
    """Resets the bake settings to default values"""
    bl_idname = "mk.render_none"
    bl_label = "None"
    bl_options = {'REGISTER'}
    
    def execute(self, context):

        if bpy.context.scene.cycles.bake_type == 'UV':
            return {'FINISHED'}
        
        render_defaults(context)
        remove_render_materials(context.scene.objects)
        SelectTexture.execute(self, context) 
        bpy.context.scene.cycles.bake_type = 'UV'
        
        return {'FINISHED'}
    
class RenderAO(bpy.types.Operator):
    """Changes settings for Ambient Occlusion bakes"""
    bl_idname = "mk.render_ao"
    bl_label = "Ambient Occlusion"
    bl_options = {'REGISTER'}

    def execute(self, context):
        
        if bpy.context.scene.cycles.bake_type == 'AO':
            return {'FINISHED'}

        render_defaults(context)
        SelectBake.execute(self, context)
        bpy.context.scene.cycles.bake_type = 'AO'
        
        return {'FINISHED'}
    
class RenderShadows(bpy.types.Operator):
    """Changes settings for Shadow bakes"""
    bl_idname = "mk.render_shadows"
    bl_label = "Shadows"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        
        if bpy.context.scene.cycles.bake_type == 'SHADOW':
            return {'FINISHED'}
        
        render_defaults(context)
        set_render_materials(context.scene.objects, 0.2)
        SelectBake.execute(self, context)
        
        for obj in context.scene.objects:
            if obj.type == 'LIGHT':
                if obj.data.type == 'SUN':
                    if not "_ShadowBake" in obj.name:
                        objclone = obj.copy()
                        obj.users_collection[0].objects.link(objclone)
                        objclone.name = obj.name + "_ShadowBake"
                        objclone.data.energy = 1
                        objclone.visible_diffuse = False
                        obj.hide_render = True
                else:
                    obj.hide_render = True
        
        bpy.context.scene.cycles.bake_type = 'SHADOW'
        
        return {'FINISHED'}

class RenderLights(bpy.types.Operator):
    """Changes settings for Light Map bakes"""
    bl_idname = "mk.render_lights"
    bl_label = "Light Map"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        
        if bpy.context.scene.cycles.bake_type == 'GLOSSY':
            return {'FINISHED'}
        
        render_defaults(context)
        set_render_materials(context.scene.objects, 1)
        SelectBake.execute(self, context)
        
        for obj in context.scene.objects:
            if obj.type == 'LIGHT':
                if obj.data.type == 'SUN':
                    obj.visible_glossy = False
                
        cycles = bpy.context.scene.cycles
        cycles.adaptive_threshold = 0.005
        cycles.samples = 750
        cycles.use_fast_gi = False
        context.scene.render.bake.use_pass_color = False
        
        cycles.bake_type = 'GLOSSY'

        return {'FINISHED'}

# Rendering functions
        
def render_defaults(context):
    remove_objs = []
    for obj in context.scene.objects:
        if obj.type == 'LIGHT':
            if obj.data.type == 'SUN':
                if '_ShadowBake' in obj.name:
                    remove_objs.append(obj)
                else:
                    obj.visible_glossy = True
            
            obj.hide_render = False
    
    for obj in remove_objs:
        bpy.data.objects.remove(obj)
        
    cycles = bpy.context.scene.cycles
    cycles.adaptive_threshold = 0.01
    cycles.samples = 250
    cycles.use_fast_gi = True
    
def set_render_materials(objects, roughness):
    for obj in objects:
            if obj.type == 'MESH' and obj != bpy.context.scene.skybox_object:
                for slot in obj.material_slots:
                    bsdf = get_bsdf_node(slot.material.node_tree.nodes)
                    reset_node_input(bsdf.inputs['Specular'], 25)
                    reset_node_input(bsdf.inputs['Metallic'], 0.000000001)
                    reset_node_input(bsdf.inputs['Roughness'], roughness)
                        
def remove_render_materials(objects):
    for obj in objects:
        if obj.type == 'MESH' and obj != bpy.context.scene.skybox_object:
            for slot in obj.material_slots:
                bsdf = get_bsdf_node(slot.material.node_tree.nodes)
                reset_node_input(bsdf.inputs['Specular'], 0.5)
                reset_node_input(bsdf.inputs['Roughness'], 0.5)
                        
                        
def reset_node_input(node_input, value):
    for link in node_input.links:
        node_input.links.remove(link)
    if value:
        node_input.default_value = value
    
def select_uv_slot(obj, slot_id):
    obj.data.uv_layers.active = obj.data.uv_layers[slot_id]
    

# Export

class ExportBakes(bpy.types.Operator):
    """Export bake textures to a specified directory"""
    bl_idname = "mk.export_bake"
    bl_label = "Export Bake Textures"
    bl_options = {'REGISTER'}

    def execute(self, context):
        
        abs_dir = bpy.path.abspath(context.scene.render_dir)
        if not os.path.isdir(abs_dir):
            self.report({'WARNING'}, "Invalid export path!")
        else:
            
            texture_names = []
            for obj in context.selected_objects:
                if obj.type == 'MESH':
                    for slot in obj.material_slots:
                        node = get_bake_node(slot.material.node_tree.nodes)
                        if node and not node.image.name in texture_names:
                            texture_names.append(node.image.name)
                            
            bake_type = "_ao"
            if  bpy.context.scene.cycles.bake_type == 'GLOSSY':
                bake_type = "_lightmap"
            elif  bpy.context.scene.cycles.bake_type == 'SHADOW':
                bake_type = "_shadow"
        
            for image in bpy.data.images:
                if image.name in texture_names:
                    image.save_render(filepath=os.path.join(abs_dir, image.name + bake_type + ".png"))

        return{'FINISHED'}


# Registration
    
classes = [
    ObjPanel,
    DeselectNonMesh,
    HomogeniseUVs,
    RemoveColorAttributes,
    AttrubutesToTextures,
    ValuesToSun,
    SunToValues,
        
    BakePanel,
    AddBakeUV,
    AddBakeTexture,
    SelectBake,
    SelectTexture,
    SetValues,
    SetValuesNight,
    SetValuesSunset,
    RenderNone,
    RenderAO,
    RenderShadows,
    RenderLights,
    ExportBakes
]

def register():
    for c in classes:
        bpy.utils.register_class(c)
        
    bpy.types.Scene.render_enum = bpy.props.EnumProperty(
        items = [('mk.render_none', 'None', '',1), 
                 ('mk.render_ao', 'Ambient Occlusion', '',2), 
                 ('mk.render_shadows', 'Shadows', '',3),
                 ('mk.render_lights', 'Light Map', '',4)],
        name = "Type",
        default = 'mk.render_none',
        update = update_render_type)
    bpy.types.Scene.render_dir = bpy.props.StringProperty(
        name="Path",
        description="Directory to save bake textures to",
        default="",
        maxlen=1024,
        subtype='DIR_PATH')
    
    bpy.types.Scene.sun_rot_x = bpy.props.FloatProperty(
        name="Sun X Rotation",
        default=0,)
    bpy.types.Scene.sun_rot_y = bpy.props.FloatProperty(
        name="Sun Y Rotation",
        default=0,)
    bpy.types.Scene.sun_rot_z = bpy.props.FloatProperty(
        name="Sun Z Rotation",
        default=0,)
    
    bpy.types.Scene.skybox_object = bpy.props.PointerProperty(
        name="Skybox",
        type=bpy.types.Object)

def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)
    del bpy.types.Scene.render_enum
    del bpy.types.Scene.render_dir
    del bpy.types.Scene.sun_rot_x
    del bpy.types.Scene.sun_rot_y
    del bpy.types.Scene.sun_rot_z
    del bpy.types.Scene.skybox_object